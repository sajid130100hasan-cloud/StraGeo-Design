package com.strageo.studio;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.PrintManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.WebSettings;
import android.webkit.ValueCallback;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.util.Base64;

import java.io.OutputStream;
import java.util.Arrays;

public class MainActivity extends Activity {
    private static final int REQUEST_IMPORT = 1001;
    private static final int REQUEST_EXPORT = 1002;
    private WebView webView;
    private WebView popupView;
    private Dialog popupDialog;
    private ValueCallback<Uri[]> uploadCallback;
    private byte[] pendingExport;
    private String pendingExportName;
    private String pendingExportMime;
    private final Handler ui = new Handler(Looper.getMainLooper());

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(16,31,55));
        getWindow().setNavigationBarColor(Color.rgb(16,31,55));
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12),dp(6),dp(8),dp(6));
        top.setBackgroundResource(R.drawable.header_bg);
        root.addView(top,new LinearLayout.LayoutParams(-1,dp(58)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title = new TextView(this);
        title.setText("Strageo Studio"); title.setTextColor(Color.WHITE);
        title.setTextSize(18); title.setTypeface(null,1);
        TextView subtitle = new TextView(this);
        subtitle.setText("BNBC 2020  •  Offline Structural Studio");
        subtitle.setTextColor(Color.rgb(184,206,231)); subtitle.setTextSize(10);
        titleBox.addView(title); titleBox.addView(subtitle);
        top.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1));

        Button about = action("About");
        about.setOnClickListener(v->showAbout());
        top.addView(about);
        Button print = action("PDF");
        print.setOnClickListener(v->printCurrent(webView));
        top.addView(print);

        webView = new WebView(this);
        root.addView(webView,new LinearLayout.LayoutParams(-1,0,1));
        configureWebView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private int dp(int value){return (int)(getResources().getDisplayMetrics().density*value+0.5f);}
    private Button action(String label){
        Button b = new Button(this);
        b.setText(label);b.setAllCaps(false);b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(Color.rgb(35,72,112)));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2,dp(42));
        lp.leftMargin=dp(4); b.setLayoutParams(lp);return b;
    }

    private void configureWebView(WebView view) {
        WebSettings s = view.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true); // app's bundled asset only
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setSupportMultipleWindows(true);
        s.setJavaScriptCanOpenWindowsAutomatically(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("UTF-8");
        view.addJavascriptInterface(new AndroidBridge(),"AndroidBridge");
        view.setWebViewClient(new WebViewClient(){
            @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest req){
                Uri u=req.getUrl();
                if ("file".equals(u.getScheme()) && "android_asset".equals(u.getHost())) return false;
                if ("about".equals(u.getScheme())) return false;
                if ("https".equals(u.getScheme()) || "http".equals(u.getScheme())) {
                    try{startActivity(new Intent(Intent.ACTION_VIEW,u));}catch(Exception ignored){}
                }
                return true;
            }
        });
        view.setWebChromeClient(new WebChromeClient(){
            @Override public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params){
                if(uploadCallback!=null)uploadCallback.onReceiveValue(null);
                uploadCallback=cb;
                Intent i=new Intent(Intent.ACTION_OPEN_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/json");
                try{startActivityForResult(i,REQUEST_IMPORT);}catch(Exception e){uploadCallback.onReceiveValue(null);uploadCallback=null;return false;}
                return true;
            }
            @Override public boolean onJsAlert(WebView w,String url,String msg,JsResult result){
                new AlertDialog.Builder(MainActivity.this).setMessage(msg).setPositiveButton("OK",(d,k)->result.confirm()).setOnCancelListener(d->result.cancel()).show();
                return true;
            }
            @Override public boolean onCreateWindow(WebView w,boolean isDialog,boolean isUserGesture,android.os.Message resultMsg){
                showPopup(resultMsg);return true;
            }
            @Override public void onCloseWindow(WebView window){closePopup();}
        });
    }

    private void showPopup(android.os.Message resultMsg){
        closePopup();
        popupView = new WebView(this);
        configureWebView(popupView);
        LinearLayout layout=new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        LinearLayout controls=new LinearLayout(this);
        controls.setGravity(Gravity.END);
        Button pdf=new Button(this);pdf.setText("Print / Save PDF");
        pdf.setOnClickListener(v->printCurrent(popupView));
        Button close=new Button(this);close.setText("Close");
        close.setOnClickListener(v->closePopup());
        controls.addView(pdf);controls.addView(close);
        layout.addView(controls,new LinearLayout.LayoutParams(-1,dp(54)));
        layout.addView(popupView,new LinearLayout.LayoutParams(-1,0,1));
        popupDialog=new Dialog(this,android.R.style.Theme_Material_Light_NoActionBar);
        popupDialog.setContentView(layout);
        popupDialog.setOnDismissListener(d->{if(popupView!=null){popupView.destroy();popupView=null;}popupDialog=null;});
        popupDialog.show();
        if(popupDialog.getWindow()!=null)popupDialog.getWindow().setLayout(-1,-1);
        WebView.WebViewTransport transport=(WebView.WebViewTransport)resultMsg.obj;
        transport.setWebView(popupView);
        resultMsg.sendToTarget();
    }
    private void closePopup(){if(popupDialog!=null){Dialog d=popupDialog;popupDialog=null;d.dismiss();}}

    private void printCurrent(WebView w){
        if(w==null)return;
        try{
            PrintManager mgr=(PrintManager)getSystemService(Context.PRINT_SERVICE);
            mgr.print("Strageo Studio Engineering Report",w.createPrintDocumentAdapter("Strageo Studio Report"),new PrintAttributes.Builder().build());
        }catch(Exception e){Toast.makeText(this,"Print unavailable: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

    private class AndroidBridge {
        @JavascriptInterface public void saveFile(String name,String mime,String base64){
            try{
                byte[] bytes=Base64.decode(base64,Base64.DEFAULT);
                if(bytes.length>30*1024*1024)throw new IllegalArgumentException("Export exceeds 30 MB");
                ui.post(()->requestSave(name,mime,bytes));
            }catch(Exception e){ui.post(()->Toast.makeText(MainActivity.this,"Export failed: "+e.getMessage(),Toast.LENGTH_LONG).show());}
        }
        @JavascriptInterface public void showAbout(){ui.post(()->MainActivity.this.showAbout());}
        @JavascriptInterface public void printPage(){ui.post(()->printCurrent(webView));}
    }

    private void requestSave(String name,String mime,byte[] bytes){
        if(pendingExport!=null){Toast.makeText(this,"Finish the previous export first",Toast.LENGTH_LONG).show();return;}
        pendingExport=bytes;
        pendingExportName=(name==null||name.isEmpty())?"Strageo_Studio_Export":name.replaceAll("[\\\\/:*?\"<>|]","_");
        pendingExportMime=(mime==null||mime.isEmpty())?"application/octet-stream":mime;
        Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(pendingExportMime);
        i.putExtra(Intent.EXTRA_TITLE,pendingExportName);
        try{startActivityForResult(i,REQUEST_EXPORT);}catch(Exception e){pendingExport=null;Toast.makeText(this,"Save picker unavailable",Toast.LENGTH_LONG).show();}
    }

    @Override protected void onActivityResult(int requestCode,int resultCode,Intent data){
        super.onActivityResult(requestCode,resultCode,data);
        if(requestCode==REQUEST_IMPORT){
            if(uploadCallback!=null){Uri[] result=resultCode==RESULT_OK&&data!=null&&data.getData()!=null?new Uri[]{data.getData()}:null;
                uploadCallback.onReceiveValue(result);uploadCallback=null;}
        }else if(requestCode==REQUEST_EXPORT){
            if(resultCode==RESULT_OK&&data!=null&&data.getData()!=null&&pendingExport!=null){
                try(OutputStream os=getContentResolver().openOutputStream(data.getData())){
                    if(os==null)throw new IllegalStateException("Could not open destination");
                    os.write(pendingExport);
                    Toast.makeText(this,"Saved: "+pendingExportName,Toast.LENGTH_SHORT).show();
                }catch(Exception e){Toast.makeText(this,"Save failed: "+e.getMessage(),Toast.LENGTH_LONG).show();}
            }
            pendingExport=null;pendingExportName=null;pendingExportMime=null;
        }
    }

    private void showAbout(){
        new AlertDialog.Builder(this)
            .setTitle("Strageo Studio · v1.0")
            .setMessage("Developed by:\nEngr. Sajid Hasan\nAssistant Professor\nDepartment of Civil Engineering\nSouthern University Bangladesh\n\nOffline BNBC 2020 structural engineering review workspace.\n\nPRELIMINARY SOFTWARE — NOT FOR CONSTRUCTION. Analysis, design, code reference tables and detailing require independent verification by the responsible structural engineer.")
            .setPositiveButton("Close",(d,w)->{}).show();
    }

    @Override public void onBackPressed(){
        if(popupDialog!=null){closePopup();return;}
        new AlertDialog.Builder(this).setTitle("Exit Strageo Studio?")
            .setMessage("Changes are stored in local autosave where available. Export your project JSON for backup.")
            .setNegativeButton("Stay",(d,w)->{}).setPositiveButton("Exit",(d,w)->finish()).show();
    }

    @Override protected void onDestroy(){
        closePopup();
        if(webView!=null){webView.destroy();webView=null;}
        super.onDestroy();
    }
}
