# Strageo Studio — Android application source (v1.0)

**App name:** Strageo Studio  
**Developed by:** Engr. Sajid Hasan  
Assistant Professor, Department of Civil Engineering  
Southern University Bangladesh

## What is included

- A native Android Java WebView application wrapping the complete offline **RC Studio BNBC 2020 Stage 14** structural analysis/design workspace.
- Bundled HTML/JavaScript engine: no internet connection needed for core modeling and analysis.
- Persistent WebView localStorage autosave; JSON project import via Android file picker.
- Export of project JSON, CSV, DXF, SVG and HTML files via Android's system **Save As** picker (no storage permissions required).
- PDF printing of the current page or generated report using Android Print / Save as PDF.
- Popup report windows, native About dialog, original launcher icon, developer credits.

## Build APK in Android Studio

1. Install **Android Studio** with **Android SDK 35** and **JDK 17**.
2. Unzip this project and choose **Open** → the `Strageo_Studio_Android` folder.
3. Let Android Studio sync Gradle (Android Gradle Plugin **8.7.3**; Gradle **8.9**). If prompted to install the Gradle distribution, select Gradle 8.9. A local Gradle wrapper JAR is not bundled.
4. Select **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Android Studio creates `app/build/outputs/apk/debug/app-debug.apk`.
6. Install on Android 8.0+; for release, sign a release APK or AAB using your own signing key.

The build environment that produced this project has no Android SDK/Gradle installation and no access to Google's package repositories, so **an APK has not been compiled or tested on an Android device**. Only the browser-based HTML engine can be tested here.

## Important notes

- The Android WebView implementation depends on an up-to-date **Android System WebView** for modern JavaScript and CSS.
- Android's Print dialog is used for PDF; it is not a built-in PDF exporter.
- Files are saved by user-selected destinations. Keep periodic project JSON backups.
- This is preliminary structural engineering software. It is **not** a validated replacement for ETABS and is **not for construction**. BNBC 2020 inputs, calculations, load paths, design and detailing require independent engineering verification.
- This project uses **no INTERNET permission**; external links (if any) open in the device's browser.

## Build APK without Android Studio (GitHub Actions)

1. Upload the contents of this project folder to a new GitHub repository, including `.github/workflows/build-apk.yml`.
2. Open **Actions → Build Strageo Studio APK → Run workflow**.
3. After a successful run, open the workflow run and download the **Strageo-Studio-debug-APK** artifact (ZIP). Extract `app-debug.apk` and install it on Android.

This workflow has not been run in this environment. The APK will be a debug-signed development build, not a release-signed production build. Do not install APKs from untrusted repositories.

## GitHub Actions SDK fix (2026-11-10)

The workflow no longer uses `android-actions/setup-android@v3`, avoiding the obsolete `sdkmanager tools` request that caused the reported failure. It installs SDK platform 35 and build-tools 35.0.0 using the GitHub-hosted runner's preinstalled command-line tools. **The updated workflow has not yet been run on GitHub**.

When uploading to GitHub, extract the ZIP and upload its **contents at repository root** (including the hidden `.github` directory). GitHub does not automatically extract a ZIP uploaded as a file.
